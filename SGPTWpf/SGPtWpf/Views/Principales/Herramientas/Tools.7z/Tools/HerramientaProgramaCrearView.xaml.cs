﻿using MahApps.Metro.Controls;
using System.Windows;

namespace SGPTWpf.Views.Principales.Herramientas.Tools
{
    /// <summary>
    /// Lógica de interacción para HerramientaProgramaCrearView.xaml
    /// </summary>
    public partial class HerramientaProgramaCrearView : MetroWindow
    {
        public HerramientaProgramaCrearView()
        {
            InitializeComponent();
        }
    }
}
