﻿using MahApps.Metro.Controls;

namespace SGPTWpf.Views.Principales.Herramientas.Tools
{
    /// <summary>
    /// Lógica de interacción para ProgramaViewImpresion.xaml
    /// </summary>
    public partial class ProgramaViewImpresion : MetroWindow
    {
        public ProgramaViewImpresion()
        {
            InitializeComponent();
            double ancho = System.Windows.SystemParameters.PrimaryScreenWidth;

            double largo = System.Windows.SystemParameters.PrimaryScreenHeight;
            //Configuracion de elementos


        }

    }
}
