﻿using MahApps.Metro.Controls;
using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;

namespace SGPTWpf.Views.Principales.Herramientas.Tools
{
    /// <summary>
    /// Lógica de interacción para DetalleHerramientasCrudView.xaml
    /// </summary>
    public partial class DetalleHerramientasCrudView : MetroWindow
    {
        public DetalleHerramientasCrudView()
        {
            InitializeComponent();
        }
        //http://www.codeproject.com/Articles/579878/MoonPdfPanel-A-WPF-based-PDF-viewer-control
        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            // Stream para cargar la imagen
            Stream stream;
            // dialogo para cargar la imagen
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Seleccione el PDF a cargar";
            openDialog.Filter = "PDF File (*.pdf)|*.pdf";
            openDialog.Multiselect = false;
            // Abrir el cuadro de dialogo para cargar una imagen de un archivo
            if (openDialog.ShowDialog() == true)
            {
                if (new FileInfo(openDialog.FileName).Length > 2097152)
                {
                    MessageBox.Show(
                    "El tamaño máximo permitido de la imagen es de 2 Megabytes",
                        "Mensaje de Sistema",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning,
                    MessageBoxResult.OK);
                    return;
                }
                try
                {
                    if ((stream = openDialog.OpenFile()) != null)
                    {
                        using (stream)
                        {
                            byte[] imageData = new byte[stream.Length];
                            //Leer la imagen en un array de bytes
                            stream.Read(imageData, 0, (int)stream.Length);
                            //Se crea el mensaje
                            //NormaLegalByte elemento = new NormaLegalByte();
                            //elemento.MyData = imageData;
                            //Messenger.Default.Send<NormaLegalByte>(elemento);
                            //txtRuta.Text = openDialog.FileName;
                            //btnBuscar.Content = "Quitar";
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: No se puede subir el archivo " + ex.Message);
                }
            }
            else
            {
                //btnBuscar.Content = "Agregar pdf";
                //txtRuta.Text = "";
            }
        }

    }
}
