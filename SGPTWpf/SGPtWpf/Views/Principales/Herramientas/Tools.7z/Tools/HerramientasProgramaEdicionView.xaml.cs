﻿using GalaSoft.MvvmLight.Messaging;
using SGPTWpf.Messages.Herramientas;
using SGPTWpf.Model.Modelo.detalleherramientas;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System;
using MahApps.Metro.Controls.Dialogs;
using System.Linq;

namespace SGPTWpf.Views.Principales.Herramientas.Tools
{
    /// <summary>
    /// Lógica de interacción para HerramientasProgramaEdicionView.xaml
    /// </summary>
    public partial class HerramientasProgramaEdicionView : UserControl
    {
        public delegate Point GetPosition(IInputElement element);
        int rowIndex = -1;
        public ObservableCollection<DetalleHerramientasModelo> listaDetalleHerramienta;
        public DetalleHerramientasModelo changedDetalleHerramientas;
        public DialogCoordinator dlg;

        public HerramientasProgramaEdicionView()
        {
            InitializeComponent();
            dlg = new DialogCoordinator();
            changedDetalleHerramientas = null;
            dgContenido.PreviewMouseLeftButtonDown += new MouseButtonEventHandler(dgContenido_PreviewMouseLeftButtonDown);
            dgContenido.Drop += new DragEventHandler(dgContenido_Drop);
            Messenger.Default.Register<HerramientasDetalleListaMensaje>(this, (herramientasDetalleListaMensaje) => ControlHerramientasDetalleListaMensaje(herramientasDetalleListaMensaje));
        }

        private void ControlHerramientasDetalleListaMensaje(HerramientasDetalleListaMensaje herramientasDetalleListaMensaje)
        {
            listaDetalleHerramienta = herramientasDetalleListaMensaje.listaElementos;
            //No se puede dejar de suscribir debido a que las actualizaciones no las toma
            //Messenger.Default.Unregister<HerramientasDetalleListaMensaje>(this);
        }


        void dgContenido_Drop(object sender, DragEventArgs e)
        {
            decimal contador = 1;
            int cuenta = 1;
            if (rowIndex < 0)
                return;
            int index = this.GetCurrentRowIndex(e.GetPosition);
            if (index < 0)
                return;
            if (index == rowIndex)
                return;
            if (index == dgContenido.Items.Count - 1)
            {
                //dlg.ShowMessageAsync(this, "El registro no puede ser eliminado ","");
                return;
            }
            changedDetalleHerramientas = listaDetalleHerramienta[rowIndex];
            listaDetalleHerramienta.RemoveAt(rowIndex);
            listaDetalleHerramienta.Insert(index, changedDetalleHerramientas);
            if (!(listaDetalleHerramienta[index].idDhPrincipalDh == null || listaDetalleHerramienta[index].idDhPrincipalDh == 0))
            {
                //Es un subprocedimiento
                cuenta = 1;
                for (int i =0;i< listaDetalleHerramienta.Count();i++)
                {

                    if (listaDetalleHerramienta[i].idDh == listaDetalleHerramienta[index].idDhPrincipalDh)
                    {
                        contador = (decimal)listaDetalleHerramienta[i].ordenDh;
                        i = listaDetalleHerramienta.Count();
                    }
                }
                //Se identifico el orden en que esta presentado y se guarda en contador
                foreach (DetalleHerramientasModelo itemDetalle in listaDetalleHerramienta)
                {
                    if (itemDetalle.idDhPrincipalDh == listaDetalleHerramienta[index].idDhPrincipalDh)
                    {
                        //Es un hijo
                        itemDetalle.ordenDh = Decimal.Add((decimal)contador, (decimal)0.01 * cuenta);
                        itemDetalle.ordenDhPadre = contador;
                        cuenta++;
                        itemDetalle.guardadoBase = false;
                    }
                }
            }
            else
            {
                //Es un procedimiento principal debe reordenarse 
                foreach (DetalleHerramientasModelo item in listaDetalleHerramienta)
                {
                if (item.idDhPrincipalDh == null || item.idDhPrincipalDh == 0)
                {
                    item.ordenDh = contador;
                    item.guardadoBase = false;
                    //Se cambian los ordenes de los hijos
                    cuenta = 1;
                    foreach (DetalleHerramientasModelo itemDetalle in listaDetalleHerramienta)
                    {
                        if (itemDetalle.idDhPrincipalDh == item.idDh)
                        {
                            //Es un hijo
                            itemDetalle.ordenDh = Decimal.Add((decimal)contador, (decimal)0.01 * cuenta);
                            cuenta++;
                            item.guardadoBase = false;
                        }
                    }
                    contador++;
                }
                }
            }
            //Reordenar la lista
            var ListaOrdenada = listaDetalleHerramienta.OrderBy(p => p.ordenDh).ToList();
            for (int i = 0; i < listaDetalleHerramienta.Count(); i++)
            {
                changedDetalleHerramientas = ListaOrdenada[i];
                listaDetalleHerramienta.RemoveAt(i);
                listaDetalleHerramienta.Insert(i, changedDetalleHerramientas);
            }
            //listaDetalleHerramienta.OrderBy(x => x.ordenDh);
            //notificarCambio(); Para darle agilidad se  elimina
        }

        private void notificarCambio()
        {
            CrudVistaADetalleGuardarMensaje mensaje = new CrudVistaADetalleGuardarMensaje();
            mensaje.guardarModificaciones = true;
            Messenger.Default.Send(mensaje);
        }

        void dgContenido_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            rowIndex = GetCurrentRowIndex(e.GetPosition);
            if (rowIndex < 0)
                return;
            dgContenido.SelectedIndex = rowIndex;
            DetalleHerramientasModelo selectedDetalleHerramientas = dgContenido.Items[rowIndex] as DetalleHerramientasModelo;
            if (selectedDetalleHerramientas == null)
                return;
            DragDropEffects dragdropeffects = DragDropEffects.Move;
            if (DragDrop.DoDragDrop(dgContenido, selectedDetalleHerramientas, dragdropeffects)
                                != DragDropEffects.None)
            {
                dgContenido.SelectedItem = selectedDetalleHerramientas;
            }
        }
        private bool GetMouseTargetRow(Visual theTarget, GetPosition position)
        {
            Rect rect = VisualTreeHelper.GetDescendantBounds(theTarget);
            Point point = position((IInputElement)theTarget);
            return rect.Contains(point);
        }
        private DataGridRow GetRowItem(int index)
        {
            if (dgContenido.ItemContainerGenerator.Status
                    != GeneratorStatus.ContainersGenerated)
                return null;
            return dgContenido.ItemContainerGenerator.ContainerFromIndex(index) as DataGridRow;
        }
        private int GetCurrentRowIndex(GetPosition pos)
        {
            int curIndex = -1;
            for (int i = 0; i < dgContenido.Items.Count; i++)
            {
                DataGridRow itm = GetRowItem(i);
                if (GetMouseTargetRow(itm, pos))
                {
                    curIndex = i;
                    break;
                }
            }
            return curIndex;
        }
    }
}
