﻿using GalaSoft.MvvmLight.Messaging;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using SGPTWpf.Messages.Navegacion;
using SGPTWpf.Messages.Navegacion.HerramientasProgramas;
using SGPTWpf.ViewModel;
using System;
using System.Windows;

namespace SGPTWpf.Views.Principales.Herramientas.Tools
{
    /// <summary>
    /// Lógica de interacción para HerramientasProgramaCrudView.xaml
    /// </summary>
    public partial class HerramientasProgramaCrudView : MetroWindow
    {
        public HerramientasProgramaCrudView()
        {
            InitializeComponent();
            double ancho = System.Windows.SystemParameters.PrimaryScreenWidth;

            double largo = System.Windows.SystemParameters.PrimaryScreenHeight;
            Messenger.Default.Register<NavegacionHerramientaPrograma>(this, (action) => ShowNavegacionHerramientaPrograma(action));

            //Configuracion de elementos

            txtNombreHerramienta.Width = ancho * 0.33;
            txtNombreHerramienta.MinWidth = ancho * 0.30;
            txtNombreHerramienta.MaxWidth = ancho * 0.33;

            cuerpoFrame.Width = ancho ;
            cuerpoFrame.MinWidth = ancho * 0.30;
            cuerpoFrame.MaxWidth = ancho;

            cuerpoFrame.Height = largo*0.792;
            cuerpoFrame.MinHeight = largo * 0.30;
            cuerpoFrame.MaxHeight = largo*0.792 ;
        }

        private void ShowNavegacionHerramientaPrograma(NavegacionHerramientaPrograma nm)
        {
            nm.View.DataContext = nm.Contexto;
            cuerpoFrame.Content = nm.View;
        }
    }
}
